SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


CREATE TABLE IF NOT EXISTS `test_data` (
  `rev_user_text` text,
  `rev_datetime` int(10) unsigned DEFAULT NULL,
  `page_title_hash` char(32) DEFAULT NULL,
  KEY `page_title_hash_idx` (`page_title_hash`),
  KEY `rev_datetime` (`rev_datetime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `test_data` (`rev_user_text`, `rev_datetime`, `page_title_hash`) VALUES
(' leader', 13, 'page1'),
(' leader', 11, 'page1'),
(' leader', 12, 'page1'),
(' follower1', 22, 'page1'),
(' follower1', 23, 'page1'),
(' follower2', 23, 'page1'),
(' follower2', 23, 'page1'),
(' follower2', 23, 'page1'),
(' leader', 301, 'page2'),
(' follower1', 302, 'page2'),
(' follower1', 311, 'page2'),
(' leader', 401, 'page3'),
(' leader', 402, 'page3'),
(' leader', 403, 'page3'),
(' leader', 404, 'page3'),
(' follower3', 405, 'page3'),
(' follower3', 411, 'page3'),
(' follower3', 412, 'page3'),
(' follower3', 413, 'page3'),
(' follower3', 414, 'page3'),
(' on-watch-list', 501, 'page4'),
(' watch-list-leader', 531, 'page4'),
(' watch-list-leader', 532, 'page4'),
(' watch-list-follower', 541, 'page4'),
(' watch-list-follower', 542, 'page4');
